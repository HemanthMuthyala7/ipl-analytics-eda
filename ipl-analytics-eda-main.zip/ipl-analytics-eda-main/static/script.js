// ─────────────────────────────────────────
//  CHART DEFAULTS
// ─────────────────────────────────────────
Chart.defaults.color = '#666';
Chart.defaults.borderColor = '#1e1e1e';
Chart.defaults.font.family = "'DM Mono', monospace";

const COLORS = [
  '#cc0000','#d4a017','#3fb950','#58a6ff',
  '#bc8cff','#ffa657','#79c0ff','#ff7b72',
  '#56d364','#f0c040'
];

const chartBase = {
  responsive: true,
  maintainAspectRatio: true,
  plugins: { legend: { display: false } },
};

let charts = {};

function destroyChart(id) {
  if (charts[id]) { charts[id].destroy(); delete charts[id]; }
}

// ─────────────────────────────────────────
//  TAB SWITCHING
// ─────────────────────────────────────────
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
  });
});

// ─────────────────────────────────────────
//  DASHBOARD
// ─────────────────────────────────────────
async function loadDashboard() {
  const data = await fetch('/api/dashboard').then(r => r.json());

  const cards = [
    { label: 'Total Matches',  value: data.total_matches },
    { label: 'Seasons',        value: data.total_seasons },
    { label: 'Teams',          value: data.total_teams },
    { label: 'Top Team',       value: data.top_team,    small: true },
    { label: 'Top POTM',       value: data.top_player,  small: true },
    { label: 'Toss Win %',     value: data.toss_win_pct + '%' },
  ];

  document.getElementById('stat-cards').innerHTML = cards.map(c => `
    <div class="stat-card">
      <div class="stat-label">${c.label}</div>
      <div class="stat-value ${c.small ? 'small' : ''}">${c.value}</div>
    </div>
  `).join('');

  // Team wins bar
  destroyChart('teamWins');
  charts['teamWins'] = new Chart(document.getElementById('teamWinsChart'), {
    type: 'bar',
    data: {
      labels: data.team_wins.labels,
      datasets: [{
        data: data.team_wins.values,
        backgroundColor: COLORS,
        borderRadius: 4,
        borderSkipped: false,
      }]
    },
    options: {
      ...chartBase,
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color: '#666', font: { size: 10 } } },
        y: { ticks: { color: '#666' }, grid: { color: '#1e1e1e' } }
      }
    }
  });

  // Toss decision doughnut
  destroyChart('tossDecision');
  charts['tossDecision'] = new Chart(document.getElementById('tossDecisionChart'), {
    type: 'doughnut',
    data: {
      labels: data.toss_decision.labels,
      datasets: [{
        data: data.toss_decision.values,
        backgroundColor: ['#cc0000', '#d4a017'],
        borderWidth: 2,
        borderColor: '#131313',
      }]
    },
    options: {
      ...chartBase,
      plugins: {
        legend: { display: true, position: 'bottom', labels: { color: '#888', boxWidth: 12 } }
      }
    }
  });

  // Season trend line
  destroyChart('seasonTrend');
  charts['seasonTrend'] = new Chart(document.getElementById('seasonTrendChart'), {
    type: 'line',
    data: {
      labels: data.seasons_trend.labels,
      datasets: [{
        data: data.seasons_trend.values,
        borderColor: '#cc0000',
        backgroundColor: 'rgba(204,0,0,0.1)',
        borderWidth: 2.5,
        pointBackgroundColor: '#d4a017',
        pointRadius: 5,
        tension: 0.3,
        fill: true,
      }]
    },
    options: {
      ...chartBase,
      scales: {
        x: { ticks: { color: '#666' } },
        y: { ticks: { color: '#666' }, grid: { color: '#1e1e1e' } }
      }
    }
  });
}

// ─────────────────────────────────────────
//  TEAM SEARCH
// ─────────────────────────────────────────
let allTeams = [];

async function initTeams() {
  allTeams = await fetch('/api/teams').then(r => r.json());
}

const teamInput = document.getElementById('teamSearch');
const teamSugg  = document.getElementById('teamSuggestions');

teamInput.addEventListener('input', () => {
  const q = teamInput.value.toLowerCase();
  const matches = allTeams.filter(t => t.toLowerCase().includes(q));
  if (!q || !matches.length) { teamSugg.style.display = 'none'; return; }
  teamSugg.style.display = 'block';
  teamSugg.innerHTML = matches.slice(0, 8).map(t =>
    `<div class="suggestion-item" data-val="${t}">${t}</div>`
  ).join('');
  teamSugg.querySelectorAll('.suggestion-item').forEach(el => {
    el.addEventListener('click', () => {
      teamInput.value = el.dataset.val;
      teamSugg.style.display = 'none';
      loadTeam(el.dataset.val);
    });
  });
});

async function loadTeam(name) {
  const d = await fetch(`/api/team/${encodeURIComponent(name)}`).then(r => r.json());
  document.getElementById('teamResult').classList.remove('hidden');
  document.getElementById('teamName').textContent = d.name;
  document.getElementById('ringPct').textContent = d.win_pct + '%';

  document.getElementById('teamStatRow').innerHTML = `
    <div class="mini-stat"><div class="label">Matches</div><div class="val">${d.total_matches}</div></div>
    <div class="mini-stat"><div class="label">Wins</div><div class="val">${d.total_wins}</div></div>
    <div class="mini-stat"><div class="label">Toss Win %</div><div class="val">${d.toss_win_pct}%</div></div>
    <div class="mini-stat"><div class="label">Best Venue</div><div class="val text">${d.top_venue}</div></div>
    <div class="mini-stat"><div class="label">Most Beaten</div><div class="val text">${d.top_opponent}</div></div>
  `;

  // ring chart
  destroyChart('teamWinRing');
  charts['teamWinRing'] = new Chart(document.getElementById('teamWinRing'), {
    type: 'doughnut',
    data: {
      datasets: [{
        data: [d.win_pct, 100 - d.win_pct],
        backgroundColor: ['#cc0000', '#1a1a1a'],
        borderWidth: 0,
      }]
    },
    options: {
      cutout: '75%',
      plugins: { legend: { display: false }, tooltip: { enabled: false } },
      animation: { animateRotate: true }
    }
  });

  // season wins bar
  destroyChart('teamSeason');
  charts['teamSeason'] = new Chart(document.getElementById('teamSeasonChart'), {
    type: 'bar',
    data: {
      labels: d.season_wins.labels,
      datasets: [{
        data: d.season_wins.values,
        backgroundColor: '#cc0000',
        borderRadius: 4,
        borderSkipped: false,
      }]
    },
    options: {
      ...chartBase,
      scales: {
        x: { ticks: { color: '#666' } },
        y: { ticks: { color: '#666', stepSize: 1 }, grid: { color: '#1e1e1e' } }
      }
    }
  });
}

// ─────────────────────────────────────────
//  PLAYER SEARCH
// ─────────────────────────────────────────
let allPlayers = [];

async function initPlayers() {
  allPlayers = await fetch('/api/players').then(r => r.json());
}

const playerInput = document.getElementById('playerSearch');
const playerSugg  = document.getElementById('playerSuggestions');

playerInput.addEventListener('input', () => {
  const q = playerInput.value.toLowerCase();
  const matches = allPlayers.filter(p => p.toLowerCase().includes(q));
  if (!q || !matches.length) { playerSugg.style.display = 'none'; return; }
  playerSugg.style.display = 'block';
  playerSugg.innerHTML = matches.slice(0, 8).map(p =>
    `<div class="suggestion-item" data-val="${p}">${p}</div>`
  ).join('');
  playerSugg.querySelectorAll('.suggestion-item').forEach(el => {
    el.addEventListener('click', () => {
      playerInput.value = el.dataset.val;
      playerSugg.style.display = 'none';
      loadPlayer(el.dataset.val);
    });
  });
});

async function loadPlayer(name) {
  const d = await fetch(`/api/player/${encodeURIComponent(name)}`).then(r => r.json());
  document.getElementById('playerResult').classList.remove('hidden');
  document.getElementById('playerName').textContent = d.name;

  document.getElementById('playerStatRow').innerHTML = `
    <div class="mini-stat"><div class="label">POTM Awards</div><div class="val">${d.potm_awards}</div></div>
    <div class="mini-stat"><div class="label">Total Runs</div><div class="val">${d.total_runs}</div></div>
    <div class="mini-stat"><div class="label">Strike Rate</div><div class="val">${d.strike_rate}</div></div>
    <div class="mini-stat"><div class="label">Wickets</div><div class="val">${d.wickets}</div></div>
    <div class="mini-stat"><div class="label">Economy</div><div class="val">${d.economy || '—'}</div></div>
  `;

  destroyChart('playerSeason');
  charts['playerSeason'] = new Chart(document.getElementById('playerSeasonChart'), {
    type: 'bar',
    data: {
      labels: d.season_awards.labels,
      datasets: [{
        data: d.season_awards.values,
        backgroundColor: '#d4a017',
        borderRadius: 4,
        borderSkipped: false,
      }]
    },
    options: {
      ...chartBase,
      scales: {
        x: { ticks: { color: '#666' } },
        y: { ticks: { color: '#666', stepSize: 1 }, grid: { color: '#1e1e1e' } }
      }
    }
  });
}

// ─────────────────────────────────────────
//  EDA TAB
// ─────────────────────────────────────────
async function loadEDA() {
  const d = await fetch('/api/eda').then(r => r.json());

  document.getElementById('edaInsights').innerHTML = [
    `⚡ ${d.super_overs} Super Overs played across all seasons`,
    `🏏 Avg win margin by runs: ${d.win_margin_runs.avg} runs`,
    `🎯 Avg win margin by wickets: ${d.win_margin_wkts.avg} wickets`,
    `🏟️ Most matches at: ${d.top_venues.labels[0]}`,
    `🌆 Most matches in: ${d.top_cities.labels[0]}`,
  ].map(t => `<div class="insight-chip">${t}</div>`).join('');

  // Bat vs Chase
  destroyChart('batChase');
  charts['batChase'] = new Chart(document.getElementById('batChaseChart'), {
    type: 'doughnut',
    data: {
      labels: d.bat_vs_chase.labels,
      datasets: [{
        data: d.bat_vs_chase.values,
        backgroundColor: ['#cc0000', '#d4a017'],
        borderWidth: 2, borderColor: '#131313',
      }]
    },
    options: {
      ...chartBase,
      plugins: { legend: { display: true, position: 'bottom', labels: { color: '#888', boxWidth: 12 } } }
    }
  });

  // Venues
  destroyChart('venue');
  charts['venue'] = new Chart(document.getElementById('venueChart'), {
    type: 'bar',
    data: {
      labels: d.top_venues.labels.map(v => v.length > 22 ? v.slice(0,22)+'…' : v),
      datasets: [{
        data: d.top_venues.values,
        backgroundColor: COLORS,
        borderRadius: 4,
        borderSkipped: false,
      }]
    },
    options: {
      ...chartBase,
      indexAxis: 'y',
      scales: {
        x: { ticks: { color: '#666' }, grid: { color: '#1e1e1e' } },
        y: { ticks: { color: '#888', font: { size: 10 } } }
      }
    }
  });

  // Cities
  destroyChart('city');
  charts['city'] = new Chart(document.getElementById('cityChart'), {
    type: 'bar',
    data: {
      labels: d.top_cities.labels,
      datasets: [{
        data: d.top_cities.values,
        backgroundColor: '#3fb950',
        borderRadius: 4,
        borderSkipped: false,
      }]
    },
    options: {
      ...chartBase,
      scales: {
        x: { ticks: { color: '#666' } },
        y: { ticks: { color: '#666' }, grid: { color: '#1e1e1e' } }
      }
    }
  });

  // Win margin runs histogram-style
  const bins = Array(20).fill(0);
  d.win_margin_runs.values.forEach(v => {
    const b = Math.min(Math.floor(v / 10), 19);
    bins[b]++;
  });
  destroyChart('marginRuns');
  charts['marginRuns'] = new Chart(document.getElementById('marginRunsChart'), {
    type: 'bar',
    data: {
      labels: bins.map((_, i) => `${i*10}-${i*10+9}`),
      datasets: [{
        data: bins,
        backgroundColor: '#58a6ff',
        borderRadius: 3,
        borderSkipped: false,
      }]
    },
    options: {
      ...chartBase,
      scales: {
        x: { ticks: { color: '#666', font: { size: 9 } }, title: { display: true, text: 'Run margin', color: '#666' } },
        y: { ticks: { color: '#666' }, grid: { color: '#1e1e1e' } }
      }
    }
  });
}

// ─────────────────────────────────────────
//  PREDICTOR
// ─────────────────────────────────────────
async function initPredictor() {
  const [teams, venues] = await Promise.all([
    fetch('/api/teams').then(r => r.json()),
    fetch('/api/venues').then(r => r.json()),
  ]);

  ['p-team1','p-team2','p-toss-winner'].forEach(id => {
    const sel = document.getElementById(id);
    sel.innerHTML = teams.map(t => `<option value="${t}">${t}</option>`).join('');
  });

  const vSel = document.getElementById('p-venue');
  vSel.innerHTML = venues.map(v => `<option value="${v}">${v}</option>`).join('');
}

document.getElementById('predictBtn').addEventListener('click', async () => {
  const body = {
    team1:         document.getElementById('p-team1').value,
    team2:         document.getElementById('p-team2').value,
    venue:         document.getElementById('p-venue').value,
    toss_winner:   document.getElementById('p-toss-winner').value,
    toss_decision: document.getElementById('p-toss-decision').value,
  };

  if (body.team1 === body.team2) {
    alert('Please select two different teams!'); return;
  }

  const btn = document.getElementById('predictBtn');
  btn.textContent = '⏳ Predicting...';
  btn.disabled = true;

  const res = await fetch('/api/predict', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  }).then(r => r.json());

  btn.textContent = '⚡ PREDICT WINNER';
  btn.disabled = false;

  if (res.error) { alert('Prediction error: ' + res.error); return; }

  document.getElementById('predictResult').classList.remove('hidden');
  document.getElementById('winnerName').textContent = res.winner;
  document.getElementById('t1Label').textContent = res.team1;
  document.getElementById('t2Label').textContent = res.team2;
  document.getElementById('t1Pct').textContent = res.team1_pct + '%';
  document.getElementById('t2Pct').textContent = res.team2_pct + '%';
  document.getElementById('t1Fill').style.width = res.team1_pct + '%';
  document.getElementById('t2Fill').style.width = res.team2_pct + '%';
});

// ─────────────────────────────────────────
//  INIT
// ─────────────────────────────────────────
loadDashboard();
initTeams();
initPlayers();
loadEDA();
initPredictor();

// close suggestions on outside click
document.addEventListener('click', e => {
  if (!e.target.closest('.search-bar')) {
    document.querySelectorAll('.suggestions').forEach(s => s.style.display = 'none');
  }
});