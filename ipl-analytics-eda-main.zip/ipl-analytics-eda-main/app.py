from flask import Flask, jsonify, render_template, request
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import warnings
warnings.filterwarnings("ignore")

app = Flask(__name__)

# ─────────────────────────────────────────
#  LOAD DATA
# ─────────────────────────────────────────
matches    = pd.read_csv("matches.csv")
deliveries = pd.read_csv("deliveries.csv")

matches.dropna(subset=["winner"], inplace=True)
matches["toss_win_match"] = (matches["toss_winner"] == matches["winner"])

# handle both old ("batsman") and new ("batter") column names
BAT_COL = "batter" if "batter" in deliveries.columns else "batsman"

# ─────────────────────────────────────────
#  TRAIN PREDICTOR
# ─────────────────────────────────────────
le_team  = LabelEncoder()
le_venue = LabelEncoder()

all_teams  = pd.concat([matches["team1"], matches["team2"]]).unique()
all_venues = matches["venue"].unique()

le_team.fit(all_teams)
le_venue.fit(all_venues)

X = pd.DataFrame({
    "team1":         le_team.transform(matches["team1"]),
    "team2":         le_team.transform(matches["team2"]),
    "venue":         le_venue.transform(matches["venue"]),
    "toss_winner":   le_team.transform(matches["toss_winner"]),
    "toss_decision": (matches["toss_decision"] == "bat").astype(int),
})
y = le_team.transform(matches["winner"])

model = RandomForestClassifier(n_estimators=200, random_state=42)
model.fit(X, y)

# ─────────────────────────────────────────
#  ROUTES
# ─────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/dashboard")
def dashboard():
    top_team   = matches["winner"].value_counts().idxmax()
    top_player = matches["player_of_match"].value_counts().idxmax()
    toss_pct   = round(matches["toss_win_match"].mean() * 100, 1)
    season_wins = matches["winner"].value_counts().head(10)

    return jsonify({
        "total_matches": int(len(matches)),
        "total_seasons": int(matches["season"].nunique()),
        "total_teams":   int(pd.concat([matches["team1"], matches["team2"]]).nunique()),
        "top_team":      top_team,
        "top_player":    top_player,
        "toss_win_pct":  toss_pct,
        "team_wins": {
            "labels": season_wins.index.tolist(),
            "values": season_wins.values.tolist(),
        },
        "seasons_trend": {
            "labels": matches["season"].value_counts().sort_index().index.astype(str).tolist(),
            "values": matches["season"].value_counts().sort_index().values.tolist(),
        },
        "toss_decision": {
            "labels": matches["toss_decision"].value_counts().index.tolist(),
            "values": matches["toss_decision"].value_counts().values.tolist(),
        }
    })


@app.route("/api/teams")
def teams():
    return jsonify(sorted(pd.concat([matches["team1"], matches["team2"]]).unique().tolist()))


@app.route("/api/team/<name>")
def team_stats(name):
    tm   = matches[(matches["team1"] == name) | (matches["team2"] == name)]
    wins = matches[matches["winner"] == name]

    toss_tm   = matches[matches["toss_winner"] == name]
    toss_wins = toss_tm[toss_tm["winner"] == name]
    toss_pct  = round(len(toss_wins) / len(toss_tm) * 100, 1) if len(toss_tm) else 0

    top_venue = wins["venue"].value_counts().idxmax() if len(wins) else "N/A"

    opponents = pd.concat([
        wins[wins["team1"] != name]["team1"],
        wins[wins["team2"] != name]["team2"]
    ])
    top_opponent = opponents.value_counts().idxmax() if len(opponents) else "N/A"
    season_perf  = wins.groupby("season").size()

    return jsonify({
        "name":          name,
        "total_matches": int(len(tm)),
        "total_wins":    int(len(wins)),
        "win_pct":       round(len(wins) / len(tm) * 100, 1) if len(tm) else 0,
        "toss_win_pct":  toss_pct,
        "top_venue":     top_venue,
        "top_opponent":  top_opponent,
        "season_wins": {
            "labels": season_perf.index.astype(str).tolist(),
            "values": season_perf.values.tolist(),
        }
    })


@app.route("/api/players")
def players():
    top = matches["player_of_match"].value_counts().head(80)
    return jsonify(top.index.tolist())


@app.route("/api/player/<name>")
def player_stats(name):
    try:
        pm = matches[matches["player_of_match"] == name]
        season_awards = pm.groupby("season").size()

        bat         = deliveries[deliveries[BAT_COL] == name]
        total_runs  = int(bat["batsman_runs"].sum()) if len(bat) else 0
        balls_faced = int(len(bat))
        strike_rate = round(total_runs / balls_faced * 100, 1) if balls_faced else 0

        bowl         = deliveries[deliveries["bowler"] == name]
        balls_bowled = int(len(bowl))

        non_batting = ["run out", "retired hurt", "obstructing the field"]
        if "dismissal_kind" in bowl.columns:
            wickets = int(bowl[
                bowl["dismissal_kind"].notna() &
                ~bowl["dismissal_kind"].isin(non_batting)
            ].shape[0])
        else:
            wickets = 0

        economy = round(bowl["total_runs"].sum() / (balls_bowled / 6), 2) if balls_bowled >= 6 else 0

        return jsonify({
            "name":         name,
            "potm_awards":  int(len(pm)),
            "total_runs":   total_runs,
            "strike_rate":  strike_rate,
            "wickets":      wickets,
            "economy":      economy,
            "season_awards": {
                "labels": season_awards.index.astype(str).tolist(),
                "values": season_awards.values.tolist(),
            }
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/eda")
def eda():
    def result_type(row):
        if row["toss_decision"] == "bat":
            return "Bat First Won" if row["toss_win_match"] else "Chase Won"
        else:
            return "Chase Won" if row["toss_win_match"] else "Bat First Won"

    matches["result_type"] = matches.apply(result_type, axis=1)
    rc          = matches["result_type"].value_counts()
    top_venues  = matches["venue"].value_counts().head(8)
    top_cities  = matches["city"].value_counts().head(8)
    win_margin_runs = matches[matches["result"] == "runs"]["result_margin"].dropna()
    win_margin_wkts = matches[matches["result"] == "wickets"]["result_margin"].dropna()

    return jsonify({
        "bat_vs_chase": {"labels": rc.index.tolist(), "values": rc.values.tolist()},
        "top_venues":   {"labels": top_venues.index.tolist(), "values": top_venues.values.tolist()},
        "top_cities":   {"labels": top_cities.index.tolist(), "values": top_cities.values.tolist()},
        "win_margin_runs": {
            "labels": list(range(len(win_margin_runs))),
            "values": win_margin_runs.tolist(),
            "avg":    round(win_margin_runs.mean(), 1),
        },
        "win_margin_wkts": {
            "labels": list(range(len(win_margin_wkts))),
            "values": win_margin_wkts.tolist(),
            "avg":    round(win_margin_wkts.mean(), 1),
        },
        "super_overs": int(matches[matches["super_over"] == "Y"].shape[0]),
    })


@app.route("/api/venues")
def venues():
    return jsonify(sorted(matches["venue"].unique().tolist()))


@app.route("/api/predict", methods=["POST"])
def predict():
    data   = request.json
    team1  = data["team1"]
    team2  = data["team2"]
    venue  = data["venue"]
    toss_w = data["toss_winner"]
    toss_d = data["toss_decision"]

    try:
        X_pred = pd.DataFrame([{
            "team1":         le_team.transform([team1])[0],
            "team2":         le_team.transform([team2])[0],
            "venue":         le_venue.transform([venue])[0],
            "toss_winner":   le_team.transform([toss_w])[0],
            "toss_decision": 1 if toss_d == "bat" else 0,
        }])

        proba   = model.predict_proba(X_pred)[0]
        classes = le_team.inverse_transform(model.classes_)

        t1_idx  = list(classes).index(team1) if team1 in classes else -1
        t2_idx  = list(classes).index(team2) if team2 in classes else -1

        t1_prob = round(float(proba[t1_idx]) * 100, 1) if t1_idx >= 0 else 50.0
        t2_prob = round(float(proba[t2_idx]) * 100, 1) if t2_idx >= 0 else 50.0
        total   = t1_prob + t2_prob
        t1_prob = round(t1_prob / total * 100, 1)
        t2_prob = round(100 - t1_prob, 1)
        winner  = team1 if t1_prob >= t2_prob else team2

        return jsonify({
            "winner": winner, "team1": team1, "team2": team2,
            "team1_pct": t1_prob, "team2_pct": t2_prob,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400


if __name__ == "__main__":
    app.run(debug=True)